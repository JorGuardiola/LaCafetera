<?php
// frontend/cart.php
session_start();
require_once __DIR__ . '/../db/connection.php';

// Inicializar carrito
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// ==========================================
// 1. LÓGICA DE BACKEND (Añadir/Eliminar)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // A) AÑADIR AL CARRITO
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        
        $product_id = $_POST['product_id'] ?? null;
        $envase = $_POST['envase'] ?? null;
        $molienda = $_POST['molienda'] ?? null;
        $tueste = $_POST['tueste'] ?? null;
        $cantidad = (int)($_POST['cantidad'] ?? 1);

        if ($product_id && $envase && $molienda && $tueste) {
            // Buscamos el SKU en la base de datos basándonos en la selección
            // Esto es seguro y robusto
            $stmt = $pdo->prepare("SELECT sku FROM producto_variantes WHERE producto_id = ? AND envase = ? AND molienda = ? AND tueste = ? LIMIT 1");
            $stmt->execute([$product_id, $envase, $molienda, $tueste]);
            $variante = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($variante) {
                $sku = $variante['sku'];
                if (isset($_SESSION['carrito'][$sku])) {
                    $_SESSION['carrito'][$sku] += $cantidad;
                } else {
                    $_SESSION['carrito'][$sku] = $cantidad;
                }
            }
        }
    }

    // B) ACTUALIZAR CANTIDAD (Desde el Carrito con JS)
    if (isset($_POST['action']) && $_POST['action'] === 'update') {
        $sku_update = $_POST['sku'];
        $nueva_cantidad = (int)$_POST['cantidad'];
        
        if (isset($_SESSION['carrito'][$sku_update]) && $nueva_cantidad >= 1) {
            $_SESSION['carrito'][$sku_update] = $nueva_cantidad;
        }
    }

    // C) ELIMINAR
    if (isset($_POST['action']) && $_POST['action'] === 'remove') {
        $sku_remove = $_POST['sku_remove'];
        if (isset($_SESSION['carrito'][$sku_remove])) {
            unset($_SESSION['carrito'][$sku_remove]);
        }
    }

    // Redirigir para evitar reenvío de formulario
    header('Location:' . BASE_URL . '/frontend/cart.php');
    exit;
}

// ==========================================
// 2. OBTENER DATOS PARA MOSTRAR
// ==========================================
$items_carrito = [];
$total_carrito = 0;

if (!empty($_SESSION['carrito'])) {
    $skus = array_keys($_SESSION['carrito']);
    if(count($skus) > 0) {
        $placeholders = implode(',', array_fill(0, count($skus), '?'));
        
        $sql = "
            SELECT pv.sku, pv.precio, pv.molienda, pv.envase, pv.tueste, p.nombre_cafe, p.imagen, p.id
            FROM producto_variantes pv
            JOIN productos p ON pv.producto_id = p.id
            WHERE pv.sku IN ($placeholders)
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($skus);
        $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($resultados as $row) {
            $sku = $row['sku'];
            if (isset($_SESSION['carrito'][$sku])) {
                $cantidad = $_SESSION['carrito'][$sku];
                $subtotal = $row['precio'] * $cantidad;
                
                $row['cantidad'] = $cantidad;
                $row['subtotal'] = $subtotal;
                
                $items_carrito[] = $row;
                $total_carrito += $subtotal;
            }
        }
    }
}

// --- LÓGICA DE ENVÍO DINÁMICA ---
// Si supera 50€, envío es 0€, si no 5€
$gastos_envio = ($total_carrito > 50) ? 0.00 : 5.00;
$total_pagar = $total_carrito + $gastos_envio;
?>


<?php include __DIR__ . '/templates/header.php'; ?>
<main>
<div class="container">
    
    <h1>Mi carrito</h1>

    <?php if (empty($items_carrito)): ?>
        <div class="carrito-vacio">
            
                <h3>Tu carrito está vacío.</h3>
                <a href="<?= BASE_URL ?>/frontend/products.php" class="boton4-btn">Ir a la tienda</a>
        </div>
    <?php else: ?>

    <div class="cart-layout">
        
        <div class="cart-list">
            <?php foreach ($items_carrito as $item): ?>
<div class="cart-item-row" id="row-<?= $item['sku'] ?>">

    <div class="cart-img">
        <a href="product.php?id=<?= $item['id'] ?>">
            <img src="<?= defined('BASE_URL') ? BASE_URL : '/lacafetera' ?>/assets/img/imgsproducts/<?= htmlspecialchars($item['imagen']) ?>" alt="Café">
        </a>
    </div>
    
    <div class="cart-info">
        <div class="cart-product-name"><?= htmlspecialchars($item['nombre_cafe']) ?></div>
        <div class="cart-sku">SKU: <?= htmlspecialchars($item['sku']) ?></div>
        <span class="variant-tag">Envase: <?= htmlspecialchars($item['envase']) ?></span>
        <span class="variant-tag">Molienda: <?= ucfirst($item['molienda']) ?></span>
        <span class="variant-tag">Tueste: <?= ucfirst($item['tueste']) ?></span>
    </div>

    <div class="mobile-hide cart-total-line">
        <span id="subtotal-<?= $item['sku'] ?>">
            <?= number_format($item['precio'], 2) ?>€
        </span>€
    </div>

    <div class="quantity-selector-widget">
        <button type="button" class="qty-btn" id="btn-minus-<?= $item['sku'] ?>"
                onclick="updateCartAjax('<?= $item['sku'] ?>', <?= $item['cantidad'] - 1 ?>)"
                <?= $item['cantidad'] <= 1 ? 'disabled style="opacity:0.3"' : '' ?>>
            -
        </button>

        <input type="text" id="input-qty-<?= $item['sku'] ?>" value="<?= $item['cantidad'] ?>" readonly>

        <button type="button" class="qty-btn" id="btn-plus-<?= $item['sku'] ?>"
                onclick="updateCartAjax('<?= $item['sku'] ?>', <?= $item['cantidad'] + 1 ?>)">
            +
        </button>
    </div>

    <form action="cart.php" method="POST" style="margin:0;">
        <input type="hidden" name="action" value="remove">
        <input type="hidden" name="sku_remove" value="<?= $item['sku'] ?>">
        <button type="submit"  class="btn-delete">
            <i class="fa-regular fa-trash-can" style="font-size:1.8rem; color: var(--primary-500);"></i>
        </button>
    </form>
</div>
<?php endforeach; ?>
        </div>

        <div class="cart-summary-box">
            <h3>Resumen del pedido</h3>
            
            <div class="summary-row">
    <span>Subtotal</span>
    <span id="summary-subtotal"><?= number_format($total_carrito, 2) ?>€</span>
</div>
            
        <div class="summary-row">
            <span>Gastos de envío</span>
            <span id="summary-shipping">
                <?php if ($total_carrito > 50): ?>
                    <span style="color:#27AE60;">
                        Gratis
                    </span>
                <?php else: ?>
                    <span><?= number_format($gastos_envio, 2) ?>€</span>
                <?php endif; ?>
            </span>
        </div>

            <hr style="border:0; border-top:1px solid #eee; margin: 15px 0;">

            <div class="summary-row total">
                 <span>Total</span>
                <span id="summary-total"><?= number_format($total_pagar, 2) ?>€</span>
            </div>
            <div class="iva-text">IVA incluido</div>

            <button class="boton4-btn" onclick="window.location.href='<?= BASE_URL ?>/frontend/checkout.php'">Tramitar pedido</button>
        </div>

    </div>
    <?php endif; ?>

</div>

<form id="formUpdateCart" action="cart.php" method="POST" style="display:none;">
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="sku" id="sku_update">
    <input type="hidden" name="cantidad" id="qty_update">
</form>
</main>

<script>
// Función para enviar el formulario oculto al hacer clic en + o -
// CÓDIGO CORREGIDO PARA EL SCRIPT AL FINAL DE cart.php

function updateCartAjax(sku, qty) {
    if (qty < 1) return;

    const formData = new FormData();
    formData.append('sku', sku);
    formData.append('cantidad', qty);

    fetch('ajaxcart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // 1. Actualiza el input de cantidad
            const inputQty = document.getElementById('input-qty-' + sku);
            if(inputQty) inputQty.value = qty;
            
            // 2. Actualiza el subtotal de esa línea (producto)
            const subRow = document.getElementById('subtotal-' + sku);
            if(subRow) subRow.innerText = data.nuevoSubtotalItem.replace('€', ''); 

            // 3. Actualiza el Resumen (Subtotal)
            const sumSub = document.getElementById('summary-subtotal');
            if(sumSub) sumSub.innerText = data.nuevoTotalCarrito;

            // 4. Actualiza el Total
            const sumTot = document.getElementById('summary-total');
            if(sumTot) sumTot.innerText = data.nuevoTotalPagar;

            // 5. CORREGIDO: Actualiza el texto de ENVÍO (Gratis o 5€)
            const sumShip = document.getElementById('summary-shipping');
            if(sumShip && data.textoEnvioHTML) {
                sumShip.innerHTML = data.textoEnvioHTML;
            }

            // 6. Actualiza el Header
            const headerCount = document.getElementById('headerCartCount');
            if (headerCount) headerCount.innerText = data.totalItemsHeader;

            // 7. Actualizar lógica de botones (deshabilitar menos si es 1)
            const btnMinus = document.getElementById('btn-minus-' + sku);
            const btnPlus = document.getElementById('btn-plus-' + sku);
            
            if(btnMinus && btnPlus) {
                btnMinus.setAttribute('onclick', `updateCartAjax('${sku}', ${qty - 1})`);
                btnPlus.setAttribute('onclick', `updateCartAjax('${sku}', ${qty + 1})`);
                btnMinus.disabled = (qty <= 1);
                btnMinus.style.opacity = (qty <= 1) ? '0.3' : '1';
            }
        }
    })
    .catch(error => console.error('Error:', error));
}
</script>
<?php include __DIR__ . "/templates/footer.php"; ?>

